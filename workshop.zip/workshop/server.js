/**
 * Created by abhishek on 21/8/16.
 */
var express=require('express');
var app=express();

var mongojs=require('mongojs');
var db = mongojs('contactlist',['contactlist']);
var bodyparser=require('body-parser');

app.use(express.static(__dirname+"/public"));
app.use(bodyparser.urlencoded({ extended: false }));
app.use(bodyparser.json());

app.get('/contactlist', function (req, res) {

    db.contactlist.find(function(err,docs) {
        console.log(docs);

        res.json(docs);
        
    });


});

app.post('/contactlist', function (req, res) {
    var contactDoc={};
    contactDoc['name']=req.body.name;
    contactDoc['email']=req.body.email;
    contactDoc['number']=req.body.number;

    console.log(contactDoc);


    db.contactlist.insert(contactDoc, function (err, docs) {

        //console.log(err);
        //console.log(docs);

        res.send(docs);
    });

});

app.delete('/contactlist/:id', function (req, res) {
    var id=req.params.id;
    //res.send(id);

    db.contactlist.remove({_id:mongojs.ObjectId(id)}, function (err, docs) {
        res.json(docs);
    })
})

app.put('/contactlist/:id/:name/:email/:number', function (req, res) {

    console.log(req.params);
    var updateModel={};
    updateModel['id']=req.params.id;
    updateModel['name']=req.params.name;
    updateModel['email']=req.params.email;
    updateModel['number']=req.params.number;

    db.contactlist.update({_id:mongojs.ObjectId(updateModel['id'])},{$set:{name:updateModel['name'],email:updateModel['email'],number:updateModel['number']}},function(err,docs){
       console.log(docs);
        res.send(docs);
    });

})




app.listen(3000, function () {

    console.log("server running");
});