var app = angular.module('contacts',[]);

//app.service('getContacts',function(){
//
//});

var contactList=[];
var contact={};
contact['name']="default";
contact['email']="default";
contact['number']=0000;


contactList.push(contact)
console.log(contact);

app.controller('contactCtrl',function($scope,$http){
    $scope.modal={};



    $scope.contactlist=contactList;

    var refresh=function(){

        $http.get('/contactlist').success(function (response) {
            console.log(response);
            $scope.contactlist=response;
        });

    }

   refresh();


    $scope.addContact=function(){
       console.log($scope.contact);

        $http.post('/contactlist',$scope.contact).success(function (response) {
            console.log(response);
            refresh();
        });

    }

    $scope.remove=function(id){
        console.log(id);

        $http.delete('/contactlist/'+id).success(function (response) {

            console.log(response);
            refresh();
        });

    }

    $scope.update_modal= function (id,name, email, number) {
       // console.log(id);

        $scope.modal['id']=id;
        $scope.modal['name']=name;
        $scope.modal['email']=email;
        $scope.modal['number']=number;

        //$scope.modal_number=number;
    }

    $scope.update=function(){
        //console.log($scope.modal);


        $http.put('/contactlist/'+$scope.modal['id']+'/'+$scope.modal['name']+'/'+$scope.modal['email']+'/'+$scope.modal['number']).success(function(response){

            console.log(response);
            refresh();
        });

    }


});